public class Client {
    private int client_id;
    private int birth_number;
	private int district_id;
 
    public Client() {
    }
 
    public String toString() {
        return String.format("%d - %d - %d",client_id,birth_number,district_id);
    }
 
    public int getClient_id() {
        return client_id;
    }

    public void setClient_id(int client_id) {
        this.client_id = client_id;
    }
	public int getBirth_number() {
        return birth_number;
    }

    public void setBirth_number(int birth_number) {
        this.birth_number = birth_number;
    }
	public int getDistrict_id() {
        return district_id;
    }

    public void setDistrict_id(int district_id) {
        this.district_id = district_id;
    }
	
}