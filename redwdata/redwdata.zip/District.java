public class District{
    private int a1;
    private String a2;
	private String a3;
    private int a4;
	private int a5;
	private int a6;
	private int a7;
	private int a8;
	private int a9;
	private float a10;
	private int a11;
	private float a12;
	private float a13;
	private int a14;
	private int a15;
	private int a16;
    public District() {
    }
 
    public String toString() {
        return String.format("%d - %s - %s -%d -%d -%d - %d - %d -%d -%f - %d - %f - %f - %d - %d - %d",a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16);
    }
 
    public int getA1() {
        return a1;
    }

    public void setA1(int a1) {
        this.a1 = a1;
    }
	   
	public String getA2() {
        return a2;
    }

    public void setA2(String a2) {
        this.a2 = a2;
    }
	   
	 public String getA3() {
        return a3;
    }

    public void setA3(String a3) {
        this.a3 = a3;
    }
	
	   public int getA4() {
        return a4;
    }

    public void setA4(int a4) {
        this.a4 = a4;
    }
	
	   public int getA5() {
        return a5;
    }

    public void setA5(int a5) {
        this.a5 = a5;
    }
	   public int getA6() {
        return a6;
    }

    public void setA6(int a6) {
        this.a6 = a6;
    }
	   public int getA7() {
        return a7;
    }

    public void setA7(int a7) {
        this.a7 = a7;
    }
	   public int getA8() {
        return a8;
    }

    public void setA8(int a8) {
        this.a8 = a8;
    }
	   public int getA9() {
        return a9;
    }

    public void setA9(int a9) {
        this.a9= a9;
    }
	   public float getA10() {
        return a10;
    }

    public void setA10(float a10) {
        this.a10 = a10;
    }
	   public int getA11() {
        return a11;
    }

    public void setA11(int a11) {
        this.a11 = a11;
    }
	   public float getA12() {
        return a12;
    }

    public void setA12(float a12) {
        this.a12 = a12;
    }
	   public float getA13() {
        return a13;
    }

    public void setA13(float a13) {
        this.a13 = a13;
    }
	   public int getA14() {
        return a14;
    }

    public void setA14(int a14) {
        this.a14= a14;
    }
	   public int getA15() {
        return a15;
    }

    public void setA15(int a15) {
        this.a15 = a15;
    }
	   public int getA16() {
        return a16;
    }

    public void setA16(int a16) {
        this.a16 = a16;
    }
	 
}